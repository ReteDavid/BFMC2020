Introduction
============

.. mdinclude:: ../../README.md
    :start-line: 1
    :end-line: 8

.. image:: ./diagrams/pics/generalArchitecture.png

.. mdinclude:: ../../README.md
    :start-line: 9
    
