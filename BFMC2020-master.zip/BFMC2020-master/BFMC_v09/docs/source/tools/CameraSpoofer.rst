Camera Spoofer Process
======================

Camera spoofer process is a video streamer process, which comunicate with other workers similarly like the CameraHandler, so it can be replaced with Camera spoofer worker for displaying the recorded videos.  

.. image:: ../diagrams/pics/ClassDiaStartUp_CameraSpoofer.png
    :align: center

.. automodule:: src.utils.cameraspoofer.cameraspooferprocess